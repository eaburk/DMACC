import { NotesApp } from "./NotesApp.js";

new NotesApp({
  container: document.getElementById("notes"),
  noteInput: document.getElementById("noteInput"),
  addNoteBtn: document.getElementById("addNoteBtn")
});

