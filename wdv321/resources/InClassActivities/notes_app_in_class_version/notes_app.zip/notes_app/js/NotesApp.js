export class NotesApp {
  constructor({container, noteInput, addNoteBtn}) {
    this.container = container;
    this.noteInput = noteInput;
    this.addNoteBtn = addNoteBtn;

    // set class property with notes from local storage
    this.notes = JSON.parse(localStorage.getItem("notes")) || [];
    this.addNoteBtn.addEventListener("click", () => this.addNote());
    this.renderNotes();
  }

  addNote() {
    const noteText = this.noteInput.value.trim();
    if (noteText) {
      this.notes.push(
        {
          noteText: noteText,
          createdAt: Date.now(),
          updatedAt: Date.now()
        }
      );
      localStorage.setItem("notes", JSON.stringify(this.notes));
      this.renderNotes();
      this.noteInput.value = "";
    }
  }

  formatDate(dateString) {
    return new Date(dateString).toLocaleString("en-US");
  }

  renderNotes() {
    this.container.innerHTML = "";
    this.notes.forEach((note, index) => {
      const noteEl = document.createElement("div");
      noteEl.classList.add("note");

      const noteText = document.createElement("span");
      noteText.textContent = note.noteText;

      const editInput = document.createElement("input");
      editInput.type = "text";
      editInput.classList.add("hidden");
      editInput.value = note.noteText;

      //edit button
      const editBtn = this.createButton({
        label: "Edit",
        handler: () => {
          editInput.classList.remove("hidden");
          noteText.classList.add("hidden");
          saveBtn.classList.remove("hidden");
          editBtn.classList.add("hidden");
        }
      });

      const saveBtn = this.createButton({
        label: "Save",
        handler: () => {
          this.notes[index] = {
            noteText: editInput.value
          };
          localStorage.setItem("notes", JSON.stringify(this.notes));
          this.renderNotes();
        },
        cssClass: "hidden"
      });

      const deleteBtn = this.createButton({
        label: "Delete",
        handler: () => {
          this.notes.splice(index, 1);
          localStorage.setItem("notes", JSON.stringify(this.notes));
          this.renderNotes();
        },
      });

      const timestampEl = document.createElement("span");

      timestampEl.textContent =
        `Created: ${this.formatDate(note.createdAt)}
          , Updated: ${this.formatDate(note.updatedAt)}`;

      noteEl.appendChild(noteText);
      noteEl.appendChild(editInput);
      noteEl.appendChild(saveBtn);
      noteEl.appendChild(editBtn);
      noteEl.appendChild(deleteBtn);
      noteEl.appendChild(timestampEl);
      this.container.appendChild(noteEl);
    });
  }

  createButton({label, handler, cssClass }) {
    const btn = document.createElement("button");
    btn.textContent = label;
    btn.addEventListener("click", handler)
    btn.classList.add(cssClass);
    return btn;
  }
}