export async function fetchData() {
  // Fetch data using the Fetch API
  // Be sure to handle errors
  //   This does not mean updating the UI with error messages
  //   Instead, throw() an error that can be captured in the calling code
  // Return the data to the calling function as a JSON object
}