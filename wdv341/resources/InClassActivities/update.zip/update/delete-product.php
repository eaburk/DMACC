<?php
  require_once __DIR__ . '/../../includes/dbConnect.php';

  $id = $_GET["id"];

  $sql = "DELETE
          FROM products
          WHERE id = :id";

  $message = "Deleted Successfully";

  try {
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    if($stmt->rowCount == 0) {
      $message = "Unable to delete - id not found";
    }
  } catch (Exception $e) {
    $message = "Unable to delete - Reason: $e";
  }

  header("Location: index.php?message=$message");
?>