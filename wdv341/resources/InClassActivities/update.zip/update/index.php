<?php
  require_once __DIR__ . '/../../includes/dbConnect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <style>
    table {
      width: 50%;
      margin: 0 auto;
    }

    table td {
      border: 1px solid;
      padding: 10px;
    }

    h3 {
      text-align: center;
      color: red;
      margin: 20px 0;
    }
  </style>
  <script>
    let productToDelete = "";
    document.addEventListener("DOMContentLoaded", (event) => {

      document.querySelectorAll(".delete-link").forEach((link) => {
        link.addEventListener("click", (event) => {
          event.preventDefault();

          productToDelete = event.target.href;
        });
      });

      document.getElementById("confirmDeleteBtn").addEventListener("click", (event) => {
        event.preventDefault();

        window.location.href = productToDelete;
      });
    });
  </script>
</head>
<body>
  <?php
    if(isset($_GET["message"])){
      echo "<h3>" . $_GET["message"] . "</h3>";
    }
  ?>
  <table>
    <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Price</th>
      <th>Action</th>
    </tr>
    <?php
      $stmt = $pdo->query("Select * FROM products");
      while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
                <td>" . $row["id"] . "</td>
                <td>" . $row["name"] . "</td>
                <td>" . $row["price"] . "</td>
                <td><a class='delete-link' data-bs-toggle='modal' data-bs-target='#confirmDeleteModal' href='delete-product.php?id=" . $row["id"] . "'>Delete</a></td>
              </tr>";
      }
    ?>
  </table>

  <div class="modal fade" id="confirmDeleteModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Confirm</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Are you sure?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="confirmDeleteBtn">Yes, delete the product</button>
        </div>
      </div>
    </div>
  </div>
</body>
</html>